const express = require('express');
const app = express();
const port = 3001;

// 启动服务器，并在控制台打印运行端口信息
app.listen(port, () => {
  console.log(`服务器在端口 ${port} 上运行`);
});

// 引入 MySQL 数据库驱动
const mysql = require('mysql');

// 创建数据库连接配置
const connection = mysql.createConnection({
  host: '120.46.52.202',
  user: '19835551353',
  password: 'cj2436586',
  database: 'blog'
});

// 引入文件路径处理模块
const path = require('path');

// 指定上传文件的存储目录
const uploadPath = path.join(__dirname, 'uploads'); 

// 引入 multer 用于处理文件上传
const multer = require('multer');

// 配置 multer 的存储设置
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // 设置文件上传的目标目录
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    // 保持文件的原始名称
    cb(null, file.originalname);
  }
});

// 创建 multer 实例
const upload = multer({ storage });

// 处理 /music 路径的 POST 请求，用于接收音频文件上传和相关信息
// app.post('/music', upload.single('audioFile'), (req, res) => {
//   const { name, singer, duration } = req.body; 
//   const filePath = path.join(uploadPath, req.file.filename);
//   // 准备将文件路径和音频信息插入到数据库
// //   const sql = 'INSERT INTO music (path, name, singer, duration) VALUES (?,?,?,?)';

// //   // 执行数据库插入操作
// //   connection.execute(sql, [filePath, name, singer, duration], (err, results) => {
// //     if (err) {
// //       // 如果数据库操作出错，返回 500 状态码和错误信息
// //       res.status(500).send('存储音乐信息时出错');
// //     } else {
// //       // 操作成功，返回成功信息
// //       res.send('音乐信息已存储');
// //     }
// //   });
// });
app.post('/music', upload.single('audioFile'), (req, res) => {
  const { name, singer, duration } = req.body;
  let filePath;
  try {
    if (req.file.originalname.includes('UTF-8')) {
      filePath = path.join(uploadPath, req.file.originalname);
    } else {
      filePath = path.join(uploadPath, iconv.decode(req.file.originalname, 'utf8'));
    }
  } catch (error) {
    return res.status(500).send('文件名处理错误');
  }
  // 后续数据库操作等代码...
});